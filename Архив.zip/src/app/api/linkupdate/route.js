export const dynamic = 'force-dynamic';


export async function GET() {
    return Response.json({link: 'https://www.UPDATELINK23333.com'})
}
export default function OfflinePage() {
    return (
        <div>
            <h1>Вы оффлайн</h1>
            <p>Нет подключения к интернету. Попробуйте позже.</p>
        </div>
    );
}
